#ifndef _REDIS_FMACRO_H
#define _REDIS_FMACRO_H

#define _DEFAULT_SOURCE

#define _GNU_SOURCE

#define _XOPEN_SOURCE 700

#define _LARGEFILE_SOURCE
#define _FILE_OFFSET_BITS 64

#endif
